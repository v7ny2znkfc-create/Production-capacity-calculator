Production Capacity Calculator V3.1 PWA

ไฟล์ที่ต้องอัปเดตใน GitHub:
1. index.html
2. manifest.webmanifest
3. sw.js

จุดเด่น:
- 4 สูตร: Volume, Capacity, Press Factor, Production Time
- คำนวณย้อนกลับโดยเว้นว่าง 1 ช่อง
- รองรับ GitHub Pages
- รองรับ PWA / Add to Home Screen
- Service Worker เวอร์ชันใหม่ช่วยให้แอปอัปเดตและใช้งานออฟไลน์ได้บางส่วน
